package edu.purdue.YL;

public interface SubmitCallbackListener {
	
	public void onSubmit();

}
