package edu.purdue.YL;

public interface StartOverCallbackListener {
	public void onStartOver();
}
